kubeadm join 192.168.99.10:6443 --token o409ry.d2cklhot4u024vqv --discovery-token-ca-cert-hash sha256:77dbcf0b2ca28ea7112992a46f2313abb20882fbe143539f3ebf39d000c2fa95 
