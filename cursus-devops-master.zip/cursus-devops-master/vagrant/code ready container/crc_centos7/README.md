## This stack is used for OpenShift 4.x Training
To use this stack you must install virtualbox and vagrant and then use `vagrant up`

[![Déployez OpenShift 4.x sur votre PC](https://user-images.githubusercontent.com/18481009/195693536-f9008bab-162d-414d-96d1-0c4947d30085.png)](https://youtu.be/9T_S6_Ot5QY "Déployez OpenShift 4.x sur votre PC")
